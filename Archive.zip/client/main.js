sAlert.config({
  effect: 'bouncyflip',
  position: 'top-left',
  timeout: 5800,
  html: false,
  onRouteClose: false,
  stack: false,
  offset: 0
});
